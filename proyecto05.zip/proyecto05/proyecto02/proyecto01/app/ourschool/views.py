
from django.urls import reverse
from django.core.mail import BadHeaderError, send_mail
from django.http import HttpResponseRedirect
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.contrib.auth.views import PasswordResetView
from django.core.mail import EmailMessage
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.shortcuts import render, redirect
from .models import Mensaje, Mensajes_chat
from .models import Usuario
from .models import Archivo


from django.shortcuts import render, redirect
from .forms import ArchivoForm
from .models import Mensajes_chat


from django.shortcuts import render, redirect
from .forms import ArchivoForm

def subir_archivo(request):
    if request.method == 'POST':
        form = ArchivoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('formulario_mensajes')  # Cambia 'ruta_de_redireccion' por la URL a la que deseas redirigir después de guardar el archivo
    else:
        form = ArchivoForm()
    return render(request, 'ourschool/formulario_mensajes.html', {'form': form})


from django.shortcuts import render, redirect
from .forms import ArchivoForm
from .models import Mensajes_chat

def formulario_mensajes(request):
    if request.method == "POST":
        mensaje_chat = request.POST.get("mensaje_chat")
        archivo_form = ArchivoForm(request.POST, request.FILES)

        if mensaje_chat:
            Mensajes_chat.objects.create(mensajes_chat=mensaje_chat)

        if archivo_form.is_valid():
            archivo_form.save()

        return redirect('formulario_mensajes')

    archivo_form = ArchivoForm()
    mensajes_chat = Mensajes_chat.objects.all()
    return render(request, 'ourschool/formulario_mensajes.html', {'archivo_form': archivo_form, 'mensajes_chat': mensajes_chat})




def inicio(request):
    return render(request, 'ourschool/inicio.html')


def registrarse(request):
    return render(request, 'ourschool/registrarse.html')


def iniciar(request):
    email = None
    clave = None

    if request.method == "POST":
        email = request.POST.get("correo")
        clave = request.POST.get("contrasena")

    try:
        usuario = Usuario.objects.get(correo=email, contrasena=clave)
        messages.success(request, "Bienvenido!")

        request.session['logueo'] = {'rol': usuario.rol,'correo':usuario.correo}
        if usuario.rol == 2:
            return render(request, 'ourschool/inicio_estudiante.html')
        elif usuario.rol == 3:
            return render(request, 'ourschool/inicio_estudiante.html')
        elif usuario.rol == 1:
            return redirect('lista_usuarios')
        else:
            messages.error(request, "Rol no válido")

    except Usuario.DoesNotExist:
        messages.error(request, "Usuario o contraseña no válidos")
        return render(request, 'ourschool/iniciar.html')


def cerrar_session(request):
    try:
        del request.session['logueo']
        messages.success(request, 'Sesión cerrada correctamente')
        return redirect('inicio')

    except Exception as e:
        messages.error(request, f'Error: {e}')
        return redirect('inicio')  # O redirige a la página que consideres apropiada en caso de error


def registro(request):
    if request.method == "POST":
        # Obtener datos del formulario
        nom_ape = request.POST.get('nombre_apellido')
        tipo_doc = request.POST.get('tipo_documento')
        num_doc = request.POST.get('numero_documento')
        tel = request.POST.get('telefono')
        cor = request.POST.get('correo')
        fec_nac = request.POST.get('fecha_nacimiento')
        contr = request.POST.get('contrasena')
        r = request.POST.get('rol')

        try:
            # Crear un nuevo objeto Usuario
            nuevo_usuario = Usuario(
                nombre_apellido=nom_ape,
                tipo_documento=tipo_doc,
                numero_documento=num_doc,
                telefono=tel,
                correo=cor,
                fecha_nacimiento=fec_nac,
                contrasena=contr,
                rol=r
            )

            # Validar el objeto
            nuevo_usuario.full_clean()

            # Guardar el objeto en la base de datos
            nuevo_usuario.save()

            messages.success(request, 'Se guardó correctamente')
            return redirect('iniciar')

        except ValidationError as e:
            messages.warning(request, f'Error: {e}')

    return HttpResponseRedirect(reverse('inicio'))


def lista_usuarios(request):
    # Obtener datos de la base de datos
    data = Usuario.objects.all()

    # Pasar los datos a la plantilla
    return render(request, 'ourschool/inicio_estudiante.html', {'data': data})


def guardar(request):
    if request.method == "POST":
        id = request.POST.get("id")
        nomb = request.POST.get("nombre")
        desc = request.POST.get("descripcion")

        if id == "":
            # crear
            try:
                cat = Categoria(
                    nombre=nomb,
                    descripcion=desc
                )
                cat.save()
                messages.success(request, "Guardado correctamente!!")
            except Exception as e:
                messages.error(request, f"Error. {e}")
        else:
            # actualizar
            try:
                q = Categoria.objects.get(pk=id)
                q.nombre = nomb
                q.descripcion = desc
                q.save()
                messages.success(request, "Actualizado correctamente!!")
            except Exception as e:
                messages.error(request, f"Error. {e}")

        return HttpResponseRedirect(reverse("tienda:listar_categorias", args=()))
    else:
        messages.warning(request, "No se enviaron datos...")
        return HttpResponseRedirect(reverse("tienda:form_cat", args=()))


def recuperar_contrasena(request):
    return PasswordResetView.as_view(
        template_name='ourschool/correo.html',
        email_template_name='ourschool/correo.html',
        success_url='/password_reset/done/',
    )(request)



def correo(request):
    if request.method == 'POST':
        destinatario = request.POST.get('email')  # Obtener el correo electrónico del formulario
        mensaje = """
            <h1 style='color:blue;'>Our School</h1>
            <h3 style='color:black;'>Su solicitud ha sido tomada correctamente, un administrador se comunicará con usted para restablecer su contraseña</h3>
            <h1 style='color:black;'>2024</h1>
            """

        try:
            msg = EmailMessage("Tienda ADSO", mensaje, settings.EMAIL_HOST_USER, [destinatario])
            msg.content_subtype = "html"  # Habilitar html
            msg.send()
            return redirect('password_reset_done')
        except BadHeaderError:
            return HttpResponse("Invalid header found.")
        except Exception as e:
            return HttpResponse(f"Error: {e}")
    else:
        # Si no es una solicitud POST, redirigir o mostrar un mensaje de error adecuado
        return HttpResponse("Método no permitido")

def eliminar_usuario(request, correo):
    if request.method == 'GET':
        usuario = get_object_or_404(Usuario, correo=correo)
        usuario.delete()
        messages.success(request, 'Usuario eliminado exitosamente.')
        return redirect('lista_usuarios')  
    else:
        return redirect('lista_usuarios')  

def admin_editar_formulario(request, correo):
    q = Usuario.objects.get(correo=correo)
    contexto = {"id": correo, "data": q}
    return render(request, 'ourschool/perfil.html', contexto)


def perfil(request):
    usuario = request.session.get("logueo", False)
    q = Usuario.objects.get(correo=usuario['correo'])
    contexto = {"data": q}
    return render(request, "ourschool/perfil.html", contexto)

def guardar_cambios_usuario(request, correo):
    if request.method == "POST":
        usuario = Usuario.objects.get(correo=correo)
        # Actualizar los campos del usuario con los datos del formulario
        usuario.nombre_apellido = request.POST.get('nombre_apellido')
        usuario.correo = request.POST.get('correo')
        usuario.contrasena = request.POST.get('contrasena')
        usuario.telefono = request.POST.get('telefono')
        # Guardar los cambios en la base de datos
        usuario.save()
        return redirect('inicio_estudiante')  # Redirigir a la página de perfil o a donde desees
    else:
        # Manejar el caso en el que no se haya enviado un formulario
        return redirect('inicio_estudiante')  # Redirigir a la página de perfil o a donde desees


def agregar_mensaje(request):
    return render(request, 'ourschool/agregar_mensaje.html')



def formulario_mensaje(request):
    if request.method == "POST":
        descripcion = request.POST.get("descripcion")
        mensaje = Mensaje(descripcion=descripcion)
        mensaje.save()
        return redirect('formulario_mensajes')  # Redirigir a la página principal del estudiante con un mensaje de éxito

    return render(request, 'ourschool/formulario_mensaje.html')



def inicio_profesor(request):
    mensajes = Mensaje.objects.all()  # Obtener todos los mensajes
    return render(request, 'ourschool/inicio_profesor.html', {'mensajes': mensajes})

def inicio_estudiante(request):
    return render(request, 'ourschool/inicio_estudiante.html')


def mensajes_profesor(request):
    mensajes = Mensaje.objects.all()  # Obtener todos los mensajes
    return render(request, 'ourschool/mensajes_profesor.html', {'mensajes': mensajes})

def eliminar_mensaje(request, mensaje_id):
    mensaje = Mensaje.objects.get(id=mensaje_id)
    mensaje.delete()
    return redirect('mensajes_profesor')

def chat(request):
    # Agregar un mensaje de prueba
    Mensajes_chat.objects.create(mensajes_chat="Mensaje de prueba")
    mensajes_chat = Mensajes_chat.objects.all()
    return render(request, 'ourschool/formulario_mensajes.html', {'mensajes_chat': mensajes_chat})



#
#def formulario_mensajes(request):
   #if request.method == "POST":
        # mensaje_chat = request.POST.get("mensaje_chat")
        # Mensajes_chat.objects.create(mensajes_chat=mensaje_chat)
        # return redirect('formulario_mensajes')
        # mensajes_chat = Mensajes_chat.objects.all()
        # return render(request, 'ourschool/formulario_mensajes.html', {'mensajes_chat': mensajes_chat})



def eliminar_mensajes(request):
    if request.method == 'POST':
        # Eliminar todos los mensajes guardados
        Mensajes_chat.objects.all().delete()
        # Redireccionar a la página principal o a donde desees
        return redirect('inicio_estudiante')
    else:
        pass

