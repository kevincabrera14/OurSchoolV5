from django.contrib import admin
from .models import *
# Register your models here.


admin.site.register(Usuario)
admin.site.register(asesoria)
admin.site.register(pagos)
admin.site.register(Mensajes_chat)
admin.site.register(Mensaje)
admin.site.register(Archivo)